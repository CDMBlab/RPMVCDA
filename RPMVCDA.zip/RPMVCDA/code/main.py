from param import parameter_parser
from model import RPMVCDA
from dataprocessing import data_pro
import torch
import numpy as np
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def train(model, train_data, optimizer, opt):
    model.train()
    for epoch in range(0, opt.epoch):
        model.zero_grad()
        score = model(train_data)
        loss = torch.nn.MSELoss(reduction='mean')
        loss = loss(score, train_data['cd_p'].to(device))
        loss.backward()
        optimizer.step()
    score = score.detach().cpu().numpy()
    scoremin, scoremax = score.min(), score.max()
    score = (score - scoremin) / (scoremax - scoremin)
    return score

def main():
    args = parameter_parser()
    dataset = data_pro(args)
    train_data = dataset

    circ_dis_data = np.array(train_data['cd_true'])
    num_c = circ_dis_data.shape[0]
    num_d = circ_dis_data.shape[1]
    zero_c = np.zeros((num_c, num_c))
    zero_d = np.zeros((num_d, num_d))
    A = np.vstack((np.hstack((zero_c, circ_dis_data)), np.hstack((circ_dis_data.T, zero_d))))

    model = RPMVCDA(args, A, circ_dis_data)
    model.to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    score = train(model, train_data, optimizer, args)

if __name__ == "__main__":
    main()
