import argparse

def parameter_parser():

    parser = argparse.ArgumentParser(description="Run RPMVCDA.")

    parser.add_argument("--dataset-path",
                        nargs="?",
                        default="../dataset",
                        help="Training datasets.")

    parser.add_argument("--epoch",
                        type=int,
                        default=650,
                        help="Number of training epochs.")

    parser.add_argument("--gcn-layers",
                        type=int,
                        default=2,
                        help="Number of Graph Convolutional Layers.")

    parser.add_argument("--out-channels",
                        type=int,
                        default=128,
                        help="out-channels of cnn.")

    parser.add_argument("--circRNA-number",
                        type=int,
                        default=585,
                        help="circRNA number.")

    parser.add_argument("--fc",
                        type=int,
                        default=32,
                        help="circRNA feature dimensions.")

    parser.add_argument("--disease-number",
                        type=int,
                        default=88,
                        help="disease number.")

    parser.add_argument("--fd",
                        type=int,
                        default=32,
                        help="disease number.")

    parser.add_argument("--view",
                        type=int,
                        default=2,
                        help="views number.")

    return parser.parse_args()