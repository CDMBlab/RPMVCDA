import csv
import torch
import random

def read_csv(path):
    with open(path, 'r', newline='') as csv_file:
        reader = csv.reader(csv_file)
        cd_data = []
        cd_data += [[float(i) for i in row] for row in reader]
        return torch.Tensor(cd_data)


def get_edge_index(matrix):
    edge_index = [[], []]
    for i in range(matrix.size(0)):
        for j in range(matrix.size(1)):
            if matrix[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
    return torch.LongTensor(edge_index)


def data_pro(args):
    dataset = dict()
    dataset['cd_p'] = read_csv(args.dataset_path + '/c_d.csv')
    dataset['cd_true'] = read_csv(args.dataset_path + '/c_d.csv')

    zero_index = []
    one_index = []
    for i in range(dataset['cd_p'].size(0)):
        for j in range(dataset['cd_p'].size(1)):
            if dataset['cd_p'][i][j] < 1:
                zero_index.append([i, j])
            if dataset['cd_p'][i][j] >= 1:
                one_index.append([i, j])
    random.shuffle(one_index)
    random.shuffle(zero_index)
    zero_tensor = torch.LongTensor(zero_index)
    one_tensor = torch.LongTensor(one_index)
    dataset['cd'] = dict()
    dataset['cd']['train'] = [one_tensor, zero_tensor]

    "circRNA GIP sim"
    cc_g_matrix = read_csv(args.dataset_path + '/circGIPSim.csv')
    cc_g_edge_index = get_edge_index(cc_g_matrix)
    dataset['cc_g'] = {'data_matrix': cc_g_matrix, 'edges': cc_g_edge_index}

    "circRNA function sim"
    cc_f_matrix = read_csv(args.dataset_path + '/circFunSim.csv')
    cc_f_edge_index = get_edge_index(cc_f_matrix)
    dataset['cc_f'] = {'data_matrix': cc_f_matrix, 'edges': cc_f_edge_index}

    "disease GIP sim"
    dd_g_matrix = read_csv(args.dataset_path + '/disGIPSim.csv')
    dd_g_edge_index = get_edge_index(dd_g_matrix)
    dataset['dd_g'] = {'data_matrix': dd_g_matrix, 'edges': dd_g_edge_index}

    "disease semantic sim"
    dd_s_matrix = read_csv(args.dataset_path + '/disSSim.csv')
    dd_s_edge_index = get_edge_index(dd_s_matrix)
    dataset['dd_s'] = {'data_matrix': dd_s_matrix, 'edges': dd_s_edge_index}

    return dataset

