import numpy as np
import torch
from torch import nn
from torch_geometric.nn import GCNConv
from torch.autograd import Variable
torch.backends.cudnn.enabled = False
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class FSRP(torch.nn.Module):
    def __init__(self, args, A, rel_matrix, coff_embedding=4, stride=1, residual=True):
        """
        :param args: Arguments object.
        """
        super(FSRP, self).__init__()
        self.args = args
        self.in_channels = self.args.out_channels
        out_channels = self.args.out_channels
        inter_channels = self.args.out_channels // coff_embedding
        self.inter_c = inter_channels

        self.PA_a = nn.Parameter(torch.from_numpy(rel_matrix.astype(np.float32)))
        nn.init.constant_(self.PA_a, 5e-2)

        self.PA_b = nn.Parameter(torch.from_numpy(rel_matrix.T.astype(np.float32)))
        nn.init.constant_(self.PA_b, 5e-2)

        self.A = Variable(torch.from_numpy(A.astype(np.float32)), requires_grad=False)

        self.conv_a = nn.Conv1d(self.in_channels, inter_channels, 1)
        self.conv_b = nn.Conv1d(self.in_channels, inter_channels, 1)
        self.conv_d = nn.Conv1d(self.in_channels, out_channels, 1)

        if self.in_channels != out_channels:
            self.down = nn.Sequential(
                nn.Conv1d(self.in_channels, out_channels, 1),
                nn.BatchNorm1d(out_channels)
            )
        else:
            self.down = lambda x: x

        self.bn = nn.BatchNorm1d(out_channels)
        self.soft = nn.Softmax(-2)
        self.relu = nn.ReLU()

        if not residual:
            self.residual = lambda x: 0
        elif (self.in_channels == out_channels) and (stride == 1):
            self.residual = lambda x: x
        elif self.in_channels != out_channels:
            self.residual = nn.Conv1d(self.in_channels, out_channels, 1)

    def forward(self, circ, dis, adj):
        circ_size = self.args.circRNA_number
        dis_size = self.args.disease_number
        N = circ_size + dis_size
        x = torch.cat((circ, dis))
        adj = torch.from_numpy(adj).to(torch.float32)

        adj[0:circ_size, circ_size:N+1] = adj[0:circ_size, circ_size:N+1] + self.PA_a
        adj[circ_size:N+1, 0:circ_size] = adj[circ_size:N+1, 0:circ_size] + self.PA_b
        A = adj

        x = x.unsqueeze(2)
        A1 = self.conv_a(x).contiguous().view(N, self.inter_c)
        A2 = self.conv_b(x).T.squeeze(0)
        A1 = self.soft(torch.matmul(A1, A2) / A1.size(-1))
        A1 = A1 + A
        A2 = x.view(N, self.in_channels)
        self_attention = torch.matmul(A1, A2).unsqueeze(2)
        z = self.conv_d(self_attention)

        y = self.bn(z)
        y = self.relu(y)
        y += self.down(x)
        out = y.squeeze(2)
        return out



class RPMVCDA(nn.Module):
    def __init__(self, args, A, rel_matrix):
        """
        :param args: Arguments object.
        """
        super(RPMVCDA, self).__init__()
        self.args = args
        self.gcn_x1_g = GCNConv(self.args.fc, self.args.fc)
        self.gcn_x1_f = GCNConv(self.args.fc, self.args.fc)
        self.gcn_x2_g = GCNConv(self.args.fc, self.args.fc)
        self.gcn_x2_f = GCNConv(self.args.fc, self.args.fc)

        self.gcn_y1_g = GCNConv(self.args.fd, self.args.fd)
        self.gcn_y1_s = GCNConv(self.args.fd, self.args.fd)
        self.gcn_y2_g = GCNConv(self.args.fd, self.args.fd)
        self.gcn_y2_s = GCNConv(self.args.fd, self.args.fd)

        self.globalAvgPool_x = nn.AvgPool2d((self.args.fc, self.args.circRNA_number), (1, 1))
        self.globalAvgPool_y = nn.AvgPool2d((self.args.fd, self.args.disease_number), (1, 1))

        self.fc1_x = nn.Linear(in_features=self.args.view*self.args.gcn_layers,
                             out_features=5*self.args.view*self.args.gcn_layers)
        self.fc2_x = nn.Linear(in_features=5*self.args.view*self.args.gcn_layers,
                             out_features=self.args.view*self.args.gcn_layers)

        self.fc1_y = nn.Linear(in_features=self.args.view * self.args.gcn_layers,
                             out_features=5 * self.args.view * self.args.gcn_layers)
        self.fc2_y = nn.Linear(in_features=5 * self.args.view * self.args.gcn_layers,
                             out_features=self.args.view * self.args.gcn_layers)

        self.sigmoidx = nn.Sigmoid()
        self.sigmoidy = nn.Sigmoid()

        self.cnn_x = nn.Conv1d(in_channels=self.args.view*self.args.gcn_layers,
                               out_channels=self.args.out_channels,
                               kernel_size=(self.args.fc, 1),
                               stride=1,
                               bias=True)
        self.cnn_y = nn.Conv1d(in_channels=self.args.view*self.args.gcn_layers,
                               out_channels=self.args.out_channels,
                               kernel_size=(self.args.fd, 1),
                               stride=1,
                               bias=True)

        self.fsrp = FSRP(args, A, rel_matrix)

    def forward(self, data):
        torch.manual_seed(1)
        x_c = torch.randn(self.args.circRNA_number, self.args.fc)
        x_d = torch.randn(self.args.disease_number, self.args.fd)

        x_c_g1 = torch.relu(self.gcn_x1_g(x_c.to(device), data['cc_g']['edges'].to(device), data['cc_g']['data_matrix'][data['cc_g']['edges'][0], data['cc_g']['edges'][1]].to(device)))
        x_c_g2 = torch.relu(self.gcn_x2_g(x_c_g1, data['cc_g']['edges'].to(device), data['cc_g']['data_matrix'][data['cc_g']['edges'][0], data['cc_g']['edges'][1]].to(device)))

        x_c_f1 = torch.relu(self.gcn_x1_f(x_c.to(device), data['cc_f']['edges'].to(device), data['cc_f']['data_matrix'][data['cc_f']['edges'][0], data['cc_f']['edges'][1]].to(device)))
        x_c_f2 = torch.relu(self.gcn_x2_f(x_c_f1, data['cc_f']['edges'].to(device), data['cc_f']['data_matrix'][data['cc_f']['edges'][0], data['cc_f']['edges'][1]].to(device)))

        y_d_g1 = torch.relu(self.gcn_y1_g(x_d.to(device), data['dd_g']['edges'].to(device), data['dd_g']['data_matrix'][data['dd_g']['edges'][0], data['dd_g']['edges'][1]].to(device)))
        y_d_g2 = torch.relu(self.gcn_y2_g(y_d_g1, data['dd_g']['edges'].to(device), data['dd_g']['data_matrix'][data['dd_g']['edges'][0], data['dd_g']['edges'][1]].to(device)))

        y_d_s1 = torch.relu(self.gcn_y1_s(x_d.to(device), data['dd_s']['edges'].to(device), data['dd_s']['data_matrix'][data['dd_s']['edges'][0], data['dd_s']['edges'][1]].to(device)))
        y_d_s2 = torch.relu(self.gcn_y2_s(y_d_s1, data['dd_s']['edges'].to(device), data['dd_s']['data_matrix'][data['dd_s']['edges'][0], data['dd_s']['edges'][1]].to(device)))

        XC = torch.cat((x_c_g1, x_c_g2, x_c_f1, x_c_f2), 1).t()
        XC = XC.view(1, self.args.view*self.args.gcn_layers, self.args.fc, -1)

        x_channel_attention = self.globalAvgPool_x(XC)
        x_channel_attention = x_channel_attention.view(x_channel_attention.size(0), -1)
        x_channel_attention = self.fc1_x(x_channel_attention)
        x_channel_attention = torch.relu(x_channel_attention)
        x_channel_attention = self.fc2_x(x_channel_attention)
        x_channel_attention = self.sigmoidx(x_channel_attention)
        x_channel_attention = x_channel_attention.view(x_channel_attention.size(0), x_channel_attention.size(1), 1, 1)
        XC_channel_attention = x_channel_attention * XC

        XC_channel_attention = torch.relu(XC_channel_attention)

        YD = torch.cat((y_d_g1, y_d_g2, y_d_s1, y_d_s2), 1).t()
        YD = YD.view(1, self.args.view*self.args.gcn_layers, self.args.fd, -1)

        y_channel_attention = self.globalAvgPool_y(YD)
        y_channel_attention = y_channel_attention.view(y_channel_attention.size(0), -1)
        y_channel_attention = self.fc1_y(y_channel_attention)
        y_channel_attention = torch.relu(y_channel_attention)
        y_channel_attention = self.fc2_y(y_channel_attention)
        y_channel_attention = self.sigmoidy(y_channel_attention)
        y_channel_attention = y_channel_attention.view(y_channel_attention.size(0), y_channel_attention.size(1), 1,1)
        YD_channel_attention = y_channel_attention * YD

        YD_channel_attention = torch.relu(YD_channel_attention)

        x = self.cnn_x(XC_channel_attention)
        x = x.view(self.args.out_channels, self.args.circRNA_number).t()

        y = self.cnn_y(YD_channel_attention)
        y = y.view(self.args.out_channels, self.args.disease_number).t()


        temp_c = np.zeros((self.args.circRNA_number, self.args.circRNA_number))
        temp_d = np.zeros((self.args.disease_number, self.args.disease_number))
        adj = np.vstack((np.hstack((temp_c, data['cd_true'].to(device))), np.hstack((data['cd_true'].t(), temp_d))))

        z = self.fsrp(x, y, adj)
        feature = torch.split(z, [self.args.circRNA_number, self.args.disease_number], dim=0)
        xx = feature[0]
        yy = feature[1]

        return xx.mm(yy.t())
